package com.example.androidvideoplayerapp.interfaces;

public interface ClickListener {
    void onClickItem(String filePath);
}

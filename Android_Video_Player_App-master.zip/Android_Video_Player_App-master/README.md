# Android_Video_Player_App
Complete Android Video Player App
<br>
List of Videos
<br>
Play Video from List
